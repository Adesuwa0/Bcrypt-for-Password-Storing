from flask import Flask, render_template, request, redirect
import sqlite3
import bcrypt
import logging

# Initialize app
app = Flask(__name__)

# Logging setup
logging.basicConfig(level=logging.INFO)

# Pepper (secret stored outside database)
PEPPER = b'super_secret_pepper'

# Rate limiting tracker
login_attempts = {}

# Initialize database
def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password_hash BLOB
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# Home route
@app.route('/')
def home():
    return redirect('/register')


# REGISTER
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Password policy
        if len(password) < 8 or not any(char.isdigit() for char in password):
            return "Password must be at least 8 characters and include a number"

        # Add pepper + hash password
        password_peppered = password.encode('utf-8') + PEPPER
        hashed = bcrypt.hashpw(password_peppered, bcrypt.gensalt(rounds=12))

        # Store in database
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)",
                  (username, hashed))
        conn.commit()
        conn.close()

        logging.info(f"User {username} registered")

        return "User registered successfully!"

    return render_template('register.html')


# LOGIN
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Rate limiting check
        if username in login_attempts and login_attempts[username] >= 3:
            return "Too many failed attempts. Try again later."

        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute("SELECT password_hash FROM users WHERE username=?", (username,))
        result = c.fetchone()
        conn.close()

        if result:
            stored_hash = result[0]

            # Add pepper before checking
            password_peppered = password.encode('utf-8') + PEPPER

            if bcrypt.checkpw(password_peppered, stored_hash):
                login_attempts[username] = 0
                logging.info(f"User {username} logged in successfully")
                return "Login successful!"
            else:
                login_attempts[username] = login_attempts.get(username, 0) + 1
                logging.warning(f"Failed login attempt for {username}")
                return "Invalid password"
        else:
            return "User not found"

    return render_template('login.html')


# Run app
if __name__ == '__main__':
    app.run(debug=True)